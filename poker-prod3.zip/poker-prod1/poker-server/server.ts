// Minimal backend for Monad Poker
// Provides basic health check endpoint - leaderboard removed due to testnet reset

import 'dotenv/config';
import express from 'express';
import cors from 'cors';

const app = express();
const port = process.env.PORT || 4000;

// Configuration
const ALLOWED_ORIGIN = process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || '';
const ALLOWED_ORIGINS = (ALLOWED_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
const JSON_LIMIT = process.env.JSON_LIMIT || '32kb';
const TRUST_PROXY = String(process.env.TRUST_PROXY || '');

app.disable('x-powered-by');
if (TRUST_PROXY === '1' || TRUST_PROXY.toLowerCase() === 'true') {
  app.set('trust proxy', 1);
}

// Middleware
app.use(cors({
  origin: function (origin, callback) {
    if (!origin) return callback(null, true);
    if (ALLOWED_ORIGINS.length === 0) return callback(null, true); // Allow all if not configured
    if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true);
    return callback(new Error('Not allowed by CORS'));
  },
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS']
}));
app.use(express.json({ limit: JSON_LIMIT }));

// Health check endpoint
app.get('/health', (_req, res) => {
  res.json({ 
    status: 'ok', 
    message: 'Monad Poker backend ready',
    note: 'Leaderboard functionality removed - Monad testnet was reset'
  });
});

// Basic info endpoint
app.get('/api/info', (_req, res) => {
  res.json({
    ok: true,
    name: 'Monad Poker',
    version: '1.0.0',
    features: ['on-chain-entropy', 'multiplayer-sync'],
    note: 'Leaderboard and Monad Games ID features removed due to testnet reset'
  });
});

// Catch-all for removed endpoints
app.all('/api/leaderboard*', (_req, res) => {
  res.status(410).json({ 
    ok: false, 
    error: 'Leaderboard feature has been removed due to Monad testnet reset' 
  });
});

app.all('/api/client/*', (_req, res) => {
  res.status(410).json({ 
    ok: false, 
    error: 'Score submission feature has been removed due to Monad testnet reset' 
  });
});

app.listen(port, () => {
  console.log(`Monad Poker backend running on port ${port}`);
  if (ALLOWED_ORIGINS.length === 0) {
    console.warn('Warning: ALLOWED_ORIGINS is empty. CORS will allow all origins.');
  }
});
