monadGamesid = cmd8euall0037le0my79qpz42

# How to integrate Monad Games ID

Monad Games ID is a cross-game solution that players can use to reserve a username. This username will be their identity in every game that integrates Monad Games ID.

This is very similar to something like Steam or PS Network!

The benefit is that now, we can create a single leaderboard comprised of scores from all games!

Monad Games ID is great UX unlock for players and the games that integrate Monad Games ID will attract more players!

Monad Games ID uses Privy Global wallet.

Games wishing to integrate Monad Games ID must register onchain. Follow the steps outlined below.

Once the game is registered, games can submit scores and transactions performed by the player onchain, steps are outlined below:

- **Register your game with Monad Games ID**
    - Visit the smart contract on the explorer
    
    ```jsx
    https://testnet.monadexplorer.com/address/0xceCBFF203C8B6044F52CE23D914A1bfD997541A4?tab=Contract
    ```
    
    - Register the game using the `registerGame` function
        - `_game` : Address that the game will use to submit scores and transaction counts onchain
        - `_name` : Game Name
        - `_image` : Game Icon/Logo
        - `_url` : URL that players can visit to play the game
    
    ![SCR-20250813-lopl.png](attachment:65c35dcf-35c1-4988-ae14-4c7aff9845ca:SCR-20250813-lopl.png)
    
- **Integrate “Sign in with Monad Games ID”**
    - Follow this Privy guide
        - https://docs.privy.io/wallets/global-wallets/integrate-a-global-wallet/login-with-a-global-wallet#using-the-privy-login-modal
        - It is recommended to use `loginMethodsAndOrder` method instead of `loginWithCrossAppAccount` method
        - **If your game allows multiple different wallets, a dedicated button for “Sign in with Monad Games ID” is recommended**
        - When asked for Cross App ID or Provider App ID use the below value,
        - **This is not the** **appId this is the Cross App ID. appId has to be your own appId from the Privy Dashboard**
        
        ```jsx
        cmd8euall0037le0my79qpz42
        ```
        
    
    ***How to enable Monad Games ID support in Privy Dashboard***
    
    ![SCR-20250813-lgpp-2.png](attachment:b1314ada-8e60-4ac9-928e-4753a4496d60:SCR-20250813-lgpp-2.png)
    
    ![SCR-20250813-lfzf.png](attachment:662cc2c9-5268-42cc-98d9-dc710543d732:SCR-20250813-lfzf.png)
    
    ![SCR-20250813-lghb-2.png](attachment:9912e857-c575-4a96-81c9-bb5bb6464383:SCR-20250813-lghb-2.png)
    
- **Get the player wallet address**
    - When the user signs in using their Monad Games ID, an embedded wallet is created for them automatically!
    - Below is the code that you can use in your game to get that wallet address
    
    ```jsx
    
    import {
      usePrivy,
      CrossAppAccountWithMetadata,
    } from "@privy-io/react-auth";
    
    export default function App() {
    	const { authenticated, user, ready, logout, login } = usePrivy();
    	
    	...
    	
    	useEffect(() => {
    		// Check if privy is ready and user is authenticated
    		if (authenticated && user && ready) {
    			// Check if user has linkedAccounts
    	    if (user.linkedAccounts.length > 0) {
    				// Get the cross app account created using Monad Games ID	    
    		    const crossAppAccount: CrossAppAccountWithMetadata = user.linkedAccounts.filter(account => account.type === "cross_app" && account.providerApp.id === "cmd8euall0037le0my79qpz42")[0] as CrossAppAccountWithMetadata;
    	
    				// The first embedded wallet created using Monad Games ID, is the wallet address
    	      if (crossAppAccount.embeddedWallets.length > 0) {
    	        setAccountAddress(crossAppAccount.embeddedWallets[0].address);
    	      }
    	    } else {
    	      setMessage("You need to link your Monad Games ID account to continue.");
    	    }
    	  }
    	}, [authenticated, user, ready]);
    	
    	...
    }
    ```
    
- **Get the username**
    
    Use the below endpoint to get the username
    
    ```jsx
    https://monad-games-id-site.vercel.app/api/check-wallet?wallet={walletAddress}
    ```
    
    - Method: `GET`
    - The `walletAddress` is the player’s Monad Games ID wallet, check **“Get the player wallet address” section** to learn more on how to get the wallet address.
    
    *Example Response:*
    
    ```jsx
    {
        "hasUsername": true,
        "user": {
            "id": 2,
            "username": "harpal",
            "walletAddress": "0x6523d..."
        }
    }
    ```
    
    - *It is possible that a player might have not reserved a username!*
        - If the player does not have a username, show a button or a link with a message, redirecting the user to the below url for registering a username.
        
        ```jsx
        https://monad-games-id-site.vercel.app/
        ```
        
        ***Example from a game***
        
        ![image.png](attachment:ede78af5-3170-419a-92ad-8d657116dae1:image.png)
        
    
- **Submitting scores and transaction count onchain**
    
    ![SCR-20250813-lsop.png](attachment:05cb3322-b6aa-4fb4-9e31-26a143c687e0:SCR-20250813-lsop.png)
    
    - You can use the `updatePlayerData` function on the smart contract to submit `scoreAmount` and `transactionAmount` for a specific `player` using their address
        - [Contract Address](https://testnet.monadexplorer.com/address/0xceCBFF203C8B6044F52CE23D914A1bfD997541A4?tab=Contract)
        
        ```jsx
        0xceCBFF203C8B6044F52CE23D914A1bfD997541A4
        ```
        
    
    - ***Make sure to submit scores and transactions to be added and not the total***
    
    - ***You can use Viem or Ethers.js or any library of your choice to make the function calls from your server or game!***
        - You can get the ABI from the explorer.
    - ***Make sure to have the score and transaction update code on the server side otherwise the player can hack the game and make it submit any score of their choice!***
- **Verifying score and transaction submission [COMING SOON]**