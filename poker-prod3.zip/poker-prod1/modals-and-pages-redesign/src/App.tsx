import React, { useState } from 'react';
import { Copy, LogOut, Plus, Users, ArrowRightLeft, Key, Send, Check, Wallet, ChevronLeft } from 'lucide-react';
import { Button, Input, Label, Card } from './components/ui/Shared';
import { CreateTableModal } from './components/CreateTableModal';
import { JoinTableModal } from './components/JoinTableModal';
import { HostWaitingPage } from './pages/HostWaitingPage';
import { JoinerWaitingPage } from './pages/JoinerWaitingPage';
// --- Main Application ---
export function App() {
  const [user, setUser] = useState<{
    username: string;
    address: string;
    balance: string;
  } | null>(null);
  const [isFlipped, setIsFlipped] = useState(false);
  const [copied, setCopied] = useState(false);
  // Navigation State
  const [view, setView] = useState<'landing' | 'host-waiting' | 'joiner-waiting'>('landing');
  // Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  // Table Data State
  const [tableData, setTableData] = useState<any>(null);
  // Mock Data
  const MOCK_USER = {
    username: 'PlayerOne',
    address: '0x71C...9A23',
    fullAddress: '0x71C7656EC7ab88b098defB751B7401B5f6d89A23',
    balance: '1,420.50'
  };
  const handleLogin = () => {
    // Simulate API call
    setTimeout(() => {
      setUser(MOCK_USER);
    }, 500);
  };
  const handleLogout = () => {
    setUser(null);
    setIsFlipped(false);
    setView('landing');
    setTableData(null);
  };
  const handleCopyAddress = () => {
    if (!user) return;
    navigator.clipboard.writeText(user.fullAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  const handleCreateTable = (data: any) => {
    setTableData({
      ...data,
      code: 'POKER-' + Math.floor(Math.random() * 10000)
    });
    setShowCreateModal(false);
    setView('host-waiting');
  };
  const handleJoinTable = (data: any) => {
    setTableData(data);
    setShowJoinModal(false);
    setView('joiner-waiting');
  };
  const handleBackHome = () => {
    setView('landing');
    setTableData(null);
  };
  // Render Views based on state
  if (view === 'host-waiting' && tableData) {
    return <HostWaitingPage tableCode={tableData.code} tableConfig={tableData} onStartGame={() => alert('Starting game...')} onBackHome={handleBackHome} />;
  }
  if (view === 'joiner-waiting' && tableData) {
    return <JoinerWaitingPage tableCode={tableData.code} nickname={tableData.nickname} onLeave={handleBackHome} />;
  }
  return <div className="min-h-screen w-full bg-zinc-950 text-zinc-100 font-sans selection:bg-zinc-800">
      {/* Navbar */}
      <header className="border-b border-zinc-800/50 bg-zinc-950/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between max-w-5xl">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-950 font-bold font-serif">
              M
            </div>
            <span className="font-serif font-bold text-lg tracking-tight">
              Monad Poker
            </span>
          </div>
          {user && <div className="flex items-center gap-4">
              <span className="text-sm text-zinc-400 hidden sm:inline-block">
                Signed in as{' '}
                <span className="text-zinc-100 font-medium">
                  {user.username}
                </span>
              </span>
              <Button variant="ghost" size="sm" onClick={handleLogout} aria-label="Log out">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>}
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 max-w-5xl">
        {!user ?
      // Pre-Auth View
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="space-y-4 max-w-lg">
              <h1 className="text-4xl sm:text-6xl font-serif font-bold tracking-tight text-zinc-100">
                Pure Poker.
                <br />
                <span className="text-zinc-500">No Distractions.</span>
              </h1>
              <p className="text-lg text-zinc-400 leading-relaxed">
                Experience the next generation of decentralized poker on Monad.
                Minimal latency, maximum transparency. Join the table today.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 w-full max-w-xs sm:max-w-md justify-center">
              <Button size="lg" onClick={handleLogin} className="w-full sm:w-auto">
                Connect Wallet
              </Button>
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Learn More
              </Button>
            </div>
          </div> :
      // Post-Auth View
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-500">
            {/* Left Column: Actions */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-2">
                <h2 className="text-2xl font-bold tracking-tight">Lobby</h2>
                <p className="text-zinc-400">
                  Select a table or create your own to get started.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="p-6 hover:bg-zinc-900 transition-colors cursor-pointer group border-zinc-800" onClick={() => setShowCreateModal(true)}>
                  <div className="h-10 w-10 rounded-full bg-zinc-800 flex items-center justify-center mb-4 group-hover:bg-zinc-700 transition-colors">
                    <Plus className="w-5 h-5 text-zinc-100" />
                  </div>
                  <h3 className="font-semibold text-lg mb-1">Create Table</h3>
                  <p className="text-sm text-zinc-400">
                    Host a private game for friends or a public tournament.
                  </p>
                </Card>

                <Card className="p-6 hover:bg-zinc-900 transition-colors cursor-pointer group border-zinc-800" onClick={() => setShowJoinModal(true)}>
                  <div className="h-10 w-10 rounded-full bg-zinc-800 flex items-center justify-center mb-4 group-hover:bg-zinc-700 transition-colors">
                    <Users className="w-5 h-5 text-zinc-100" />
                  </div>
                  <h3 className="font-semibold text-lg mb-1">Join Table</h3>
                  <p className="text-sm text-zinc-400">
                    Browse active tables and jump into the action immediately.
                  </p>
                </Card>
              </div>
            </div>

            {/* Right Column: Wallet Card */}
            <div className="lg:col-span-5">
              <div className="sticky top-24">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">Wallet</h2>
                  <span className="text-xs text-zinc-500 font-mono">
                    MONAD TESTNET
                  </span>
                </div>

                {/* Flippable Card Container */}
                <div className="relative w-full aspect-[1.586/1] group perspective-1000 mb-4 sm:mb-6">
                  <div className={`relative w-full h-full transition-all duration-700 transform-style-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
                    {/* FRONT OF CARD */}
                    <div className="absolute w-full h-full backface-hidden">
                      <Card className="w-full h-full p-6 flex flex-col justify-between bg-gradient-to-br from-zinc-900 to-zinc-950 border-zinc-800 shadow-xl relative overflow-hidden">
                        {/* Decorative background elements */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-zinc-800/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>

                        <div className="flex justify-between items-start z-10">
                          <div className="flex items-center gap-2">
                            <div className="p-2 bg-zinc-800 rounded-lg">
                              <Wallet className="w-5 h-5 text-zinc-300" />
                            </div>
                            <span className="font-medium text-zinc-300">
                              Main Wallet
                            </span>
                          </div>
                          <div className="flex items-center gap-2 bg-zinc-900/50 rounded-full px-3 py-1 border border-zinc-800">
                            <span className="text-xs font-mono text-zinc-400">
                              {user.address}
                            </span>
                            <button onClick={handleCopyAddress} className="text-zinc-500 hover:text-zinc-300 transition-colors focus:outline-none" aria-label="Copy address">
                              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                        </div>

                        <div className="z-10">
                          <div className="text-zinc-400 text-sm font-medium mb-1">
                            Total Balance
                          </div>
                          <div className="text-4xl font-bold text-zinc-100 tracking-tight flex items-baseline gap-2">
                            {user.balance}{' '}
                            <span className="text-lg text-zinc-500 font-normal">
                              MON
                            </span>
                          </div>
                        </div>

                        <div className="z-10 pt-4 border-t border-zinc-800/50">
                          <Button className="w-full bg-zinc-100 text-zinc-950 hover:bg-zinc-200" onClick={() => setIsFlipped(true)}>
                            <Send className="w-4 h-4 mr-2" />
                            Send Token
                          </Button>
                        </div>
                      </Card>
                    </div>

                    {/* BACK OF CARD */}
                    <div className="absolute w-full h-full backface-hidden rotate-y-180 pointer-events-auto" style={{
                  zIndex: isFlipped ? 10 : -1
                }}>
                      <Card className="w-full h-full p-6 flex flex-col bg-zinc-900 border-zinc-800 shadow-xl relative touch-auto">
                        <div className="flex items-center justify-between mb-6 relative z-20">
                          <button onClick={() => setIsFlipped(false)} className="flex items-center text-sm text-zinc-400 hover:text-zinc-200 transition-colors min-h-[44px] -ml-2 pl-2 pr-3 touch-manipulation" type="button">
                            <ChevronLeft className="w-4 h-4 mr-1" />
                            Back
                          </button>
                          <span className="text-sm font-medium text-zinc-300">
                            Send MON
                          </span>
                        </div>

                        <div className="space-y-5 flex-1 relative z-10">
                          <div className="space-y-2">
                            <Label htmlFor="recipient" className="text-sm">
                              Recipient Address
                            </Label>
                            <Input id="recipient" placeholder="0x..." className="bg-zinc-950/50 border-zinc-800 h-10 text-sm touch-manipulation" type="text" />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="amount" className="text-sm">
                              Amount (MON)
                            </Label>
                            <div className="relative">
                              <Input id="amount" placeholder="0.00" className="bg-zinc-950/50 border-zinc-800 h-10 text-sm pr-16 touch-manipulation" type="number" step="0.01" />
                              <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-zinc-200 px-2 py-1 rounded bg-zinc-800 touch-manipulation">
                                MAX
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 mt-6 pt-4 border-t border-zinc-800/50 relative z-20">
                          <Button variant="outline" size="md" className="w-full border-zinc-700 min-h-[44px] touch-manipulation" type="button">
                            <Key className="w-4 h-4 mr-2" />
                            Export Key
                          </Button>
                          <Button size="md" className="w-full min-h-[44px] touch-manipulation" onClick={() => setIsFlipped(false)} type="button">
                            <ArrowRightLeft className="w-4 h-4 mr-2" />
                            Send Now
                          </Button>
                        </div>
                      </Card>
                    </div>
                  </div>
                </div>

                {/* Warning text - now outside the flip container with fixed positioning */}
                <div className="p-3 sm:p-4 rounded-lg bg-zinc-900/30 border border-zinc-800/50">
                  <p className="text-[11px] sm:text-xs text-zinc-500 text-center leading-relaxed">
                    Your keys are stored locally. Never share your private key
                    with anyone.
                  </p>
                </div>
              </div>
            </div>
          </div>}
      </main>

      {/* Modals */}
      <CreateTableModal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} onCreateTable={handleCreateTable} />
      <JoinTableModal isOpen={showJoinModal} onClose={() => setShowJoinModal(false)} onJoinTable={handleJoinTable} />

      {/* CSS for 3D Flip Effect */}
      <style>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .transform-style-3d {
          transform-style: preserve-3d;
        }
        .backface-hidden {
          backface-visibility: hidden;
          -webkit-backface-visibility: hidden;
        }
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
        .touch-manipulation {
          touch-action: manipulation;
          -webkit-tap-highlight-color: transparent;
        }
        .touch-auto {
          touch-action: auto;
        }
      `}</style>
    </div>;
}